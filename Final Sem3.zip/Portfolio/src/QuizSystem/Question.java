package QuizSystem;

import java.util.Arrays;

// Question class - stores data for a single quiz question
public class Question {
    
    // Question data
    private int questionId;
    private String questionText;
    private String[] options;
    private int correctAnswerIndex;
    private String level;

    // Constructor - creates a new question with all details
    public Question(int questionId, String questionText, String[] options, int correctAnswerIndex, String level) {
        this.questionId = questionId;
        this.questionText = questionText;
        this.options = options;
        this.correctAnswerIndex = correctAnswerIndex;
        this.level = level;
    }

    // Returns the question ID
    public int getQuestionId() {
        return questionId;
    }

    // Returns the question text
    public String getQuestionText() {
        return questionText;
    }

    // Returns the answer options array
    public String[] getOptions() {
        return options;
    }

    // Returns the correct answer index (0-based)
    public int getCorrectAnswerIndex() {
        return correctAnswerIndex;
    }

    // Returns the difficulty level
    public String getLevel() {
        return level;
    }

    // Sets the question text
    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    // Sets the answer options
    public void setOptions(String[] options) {
        this.options = options;
    }

    // Sets the correct answer index
    public void setCorrectAnswerIndex(int correctAnswerIndex) {
        this.correctAnswerIndex = correctAnswerIndex;
    }

    // Sets the difficulty level
    public void setLevel(String level) {
        this.level = level;
    }

    // Checks if the given answer index is correct
    public boolean isCorrect(int userAnswerIndex) {
        return userAnswerIndex == correctAnswerIndex;
    }

    // Returns question info as a readable string
    @Override
    public String toString() {
        return "Question ID: " + questionId + "\n" +
               "Question: " + questionText + "\n" +
               "Options: " + Arrays.toString(options) + "\n" +
               "Correct Answer: " + (correctAnswerIndex + 1) + "\n" +
               "Level: " + level;
    }
}