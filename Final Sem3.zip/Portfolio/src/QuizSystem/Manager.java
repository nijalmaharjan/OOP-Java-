package QuizSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

// Manager class - main controller for the competition management system
public class Manager {
    
    // Database connection settings
    private static final String DB_URL = "jdbc:mysql://localhost:3306/quiz_management";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    
    private Connection connection;
    private CompetitorList competitorList;
    
    // Constructor - connects to database and initializes competitor list
    public Manager() throws SQLException {
        connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        competitorList = new CompetitorList(connection);
    }
    
    // Generates and returns complete report
    public String generateFullReport() throws SQLException {
        // Load all competitors from database
        competitorList.loadCompetitors();
        
        // Generate and return full report
        return competitorList.generateFullReport();
    }
    
    // Gets competitor by ID and returns short details
    public String getCompetitorShortDetails(int competitorId) throws SQLException {
        Competitor competitor = competitorList.getCompetitor(competitorId);
        
        if (competitor != null) {
            return competitor.getShortDetails();
        } else {
            return "Competitor with ID " + competitorId + " not found.";
        }
    }
    
    // Gets competitor by ID and returns full details
    public String getCompetitorFullDetails(int competitorId) throws SQLException {
        Competitor competitor = competitorList.getCompetitor(competitorId);
        
        if (competitor != null) {
            return competitor.getFullDetails();
        } else {
            return "Competitor with ID " + competitorId + " not found.";
        }
    }
    
    // Runs interactive menu for user
    public void runMenu() {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        
        System.out.println("Competition Management System");
        System.out.println("=============================\n");
        
        while (running) {
            displayMenu();
            
            int choice = getValidChoice(scanner);
            
            try {
                switch (choice) {
                    case 1:
                        handleViewAllCompetitors();
                        break;
                    case 2:
                        handleViewCompetitorDetails(scanner);
                        break;
                    case 3:
                        handleGenerateFullReport();
                        break;
                    case 4:
                        handleViewTopPerformer();
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                System.err.println("Database error: " + e.getMessage());
            }
            
            System.out.println();
        }
        
        scanner.close();
    }
    
    // Displays menu options
    private void displayMenu() {
        System.out.println("Menu:");
        System.out.println("1. View All Competitors");
        System.out.println("2. View Competitor Details (by ID)");
        System.out.println("3. Generate Full Report");
        System.out.println("4. View Top Performer");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
    }
    
    // Gets valid menu choice from user
    private int getValidChoice(Scanner scanner) {
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next();
            System.out.print("Enter your choice: ");
        }
        int choice = scanner.nextInt();
        scanner.nextLine();
        return choice;
    }
    
    // Handles viewing all competitors
    private void handleViewAllCompetitors() throws SQLException {
        competitorList.loadCompetitors();
        System.out.println("\n" + competitorList.generateReport());
    }
    
    // Handles viewing individual competitor details
    private void handleViewCompetitorDetails(Scanner scanner) throws SQLException {
        System.out.print("Enter Competitor ID: ");
        
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next();
            System.out.print("Enter Competitor ID: ");
        }
        
        int id = scanner.nextInt();
        scanner.nextLine();
        
        System.out.println("\nFull Details:");
        System.out.println(getCompetitorFullDetails(id));
        
        System.out.println("\nShort Details:");
        System.out.println(getCompetitorShortDetails(id));
    }
    
    // Handles generating full report
    private void handleGenerateFullReport() throws SQLException {
        System.out.println("\nGenerating Full Report...\n");
        String report = generateFullReport();
        System.out.println(report);
    }
    
    // Handles viewing top performer
    private void handleViewTopPerformer() throws SQLException {
        competitorList.loadCompetitors();
        Competitor top = competitorList.getTopPerformer();
        
        if (top != null) {
            System.out.println("\nTop Performer:");
            System.out.println(top.getFullDetails());
        } else {
            System.out.println("No competitors found.");
        }
    }
    
    // Closes database connection
    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }
    
    // Main method to run the manager
    public static void main(String[] args) {
        try {
            Manager manager = new Manager();
            manager.runMenu();
            manager.close();
        } catch (SQLException e) {
            System.err.println("Failed to start application: " + e.getMessage());
        }
    }
}