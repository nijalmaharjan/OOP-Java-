package QuizSystem;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

// CompetitorList class - manages a collection of competitors and generates reports
public class CompetitorList {
    
    private List<Competitor> competitors;
    private CompetitorDAO competitorDAO;
    
    // Constructor - takes database connection
    public CompetitorList(Connection connection) {
        this.competitorDAO = new CompetitorDAO(connection);
        this.competitors = new ArrayList<>();
    }
    
    // Loads all competitors from database
    public void loadCompetitors() throws SQLException {
        // Get top 100 competitors (essentially all)
        competitors = competitorDAO.getHighScores(100);
    }
    
    // Gets competitor by ID from database
    public Competitor getCompetitor(int id) throws SQLException {
        return competitorDAO.getCompetitor(id);
    }
    
    // Returns list of all loaded competitors
    public List<Competitor> getAllCompetitors() {
        return competitors;
    }
    
    // Generates full report table of all competitors
    public String generateReport() {
        StringBuilder report = new StringBuilder();
        
        // Table header
        report.append("Competitor Table:\n");
        report.append(String.format("%-5s %-25s %-15s %-10s%n", 
            "ID", "Name", "Level", "Overall"));
        report.append("-".repeat(60)).append("\n");
        
        // Each competitor row
        for (Competitor c : competitors) {
            report.append(String.format("%-5d %-25s %-15s %-10.1f%n",
                c.getCompetitorId(), 
                c.getName(), 
                c.getLevel() != null ? c.getLevel() : "N/A",
                c.getOverallScore()));
        }
        
        return report.toString();
    }
    
    // Gets the competitor with highest score
    public Competitor getTopPerformer() {
        if (competitors.isEmpty()) {
            return null;
        }
        
        Competitor topCompetitor = competitors.get(0);
        
        for (Competitor c : competitors) {
            if (c.getHighScore() > topCompetitor.getHighScore()) {
                topCompetitor = c;
            }
        }
        
        return topCompetitor;
    }
    
    // Generates frequency report of scores
    public String getScoreFrequency() {
        // Array to count frequency of each score (0-25)
        int[] frequency = new int[26];
        
        // Count each score
        for (Competitor c : competitors) {
            int score = c.getHighScore();
            if (score >= 0 && score < frequency.length) {
                frequency[score]++;
            }
        }
        
        // Build frequency report
        StringBuilder report = new StringBuilder();
        report.append("Frequency of Individual Scores:\n");
        
        // Only show scores that have occurred
        report.append("Score:     ");
        for (int i = 0; i < frequency.length; i++) {
            if (frequency[i] > 0) {
                report.append(String.format("%-3d ", i));
            }
        }
        
        report.append("\nFrequency: ");
        for (int i = 0; i < frequency.length; i++) {
            if (frequency[i] > 0) {
                report.append(String.format("%-3d ", frequency[i]));
            }
        }
        
        return report.toString();
    }
    
    // Generates complete report with all sections
    public String generateFullReport() {
        StringBuilder fullReport = new StringBuilder();
        
        // Section 1: Competitor Table
        fullReport.append(generateReport()).append("\n\n");
        
        // Section 2: Top Performer
        Competitor top = getTopPerformer();
        if (top != null) {
            fullReport.append("Top Performer:\n");
            fullReport.append(top.getFullDetails()).append("\n\n");
        }
        
        // Section 3: Statistics
        fullReport.append("Statistical Summary:\n");
        fullReport.append("Total number of competitors: ").append(competitors.size()).append("\n");
        
        if (top != null) {
            fullReport.append("Competitor with the highest score: ");
            fullReport.append(top.getName());
            fullReport.append(" with an overall score of ");
            fullReport.append(top.getOverallScore()).append("\n\n");
        }
        
        // Section 4: Frequency Report
        fullReport.append(getScoreFrequency()).append("\n");
        
        return fullReport.toString();
    }
    
    // Gets total number of competitors
    public int getTotalCompetitors() {
        return competitors.size();
    }
    
    // Checks if a competitor ID exists
    public boolean competitorExists(int id) {
        for (Competitor c : competitors) {
            if (c.getCompetitorId() == id) {
                return true;
            }
        }
        return false;
    }
    
    // Finds and returns competitor by ID from loaded list
    public Competitor findCompetitorById(int id) {
        for (Competitor c : competitors) {
            if (c.getCompetitorId() == id) {
                return c;
            }
        }
        return null;
    }
}