package QuizSystem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// CompetitorDAO class - handles all database operations for competitors
public class CompetitorDAO {
    
    // Database connection
    private Connection connection;

    // Constructor - takes database connection as parameter
    public CompetitorDAO(Connection connection) {
        this.connection = connection;
    }

    // Gets a competitor from database by their ID
    // Returns null if not found
    public Competitor getCompetitor(int competitorId) throws SQLException {
        
        String query = "SELECT name, age, level, highscore FROM competitors WHERE competitor_id = ?";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, competitorId);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String name = resultSet.getString("name");
                    int age = resultSet.getInt("age");
                    String level = resultSet.getString("level");
                    int highScore = resultSet.getInt("highscore");
                    
                    return new Competitor(competitorId, name, age, level, highScore);
                }
            }
        }
        
        return null;
    }

    // Creates a new competitor in the database
    // Returns the new competitor ID or -1 if failed
    public int createCompetitor(String name, int age) throws SQLException {
        
        String query = "INSERT INTO competitors (name, age, level, highscore) VALUES (?, ?, ?, ?)";
        
        try (PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, name);
            statement.setInt(2, age);
            statement.setString(3, null); // Level starts as null
            statement.setInt(4, 0);       // High score starts at 0
            statement.executeUpdate();
            
            // Get the auto-generated ID
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }
        }
        
        return -1;
    }

    // Gets competitor ID by name and age
    // Returns -1 if not found
    public int getCompetitorId(String name, int age) throws SQLException {
        
        String query = "SELECT competitor_id FROM competitors WHERE name = ? AND age = ?";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, name);
            statement.setInt(2, age);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt("competitor_id");
                }
            }
        }
        
        return -1;
    }

    // Updates high score only if new score is higher than current
    public void updateHighScore(int competitorId, int score) throws SQLException {
        
        // GREATEST keeps the higher value between current and new score
        String query = "UPDATE competitors SET highscore = GREATEST(highscore, ?) WHERE competitor_id = ?";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, score);
            statement.setInt(2, competitorId);
            statement.executeUpdate();
        }
    }

    // Updates the level for a competitor
    public void updateLevel(int competitorId, String level) throws SQLException {
        
        String query = "UPDATE competitors SET level = ? WHERE competitor_id = ?";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, level);
            statement.setInt(2, competitorId);
            statement.executeUpdate();
        }
    }

    // Gets competitor with their individual scores
    // Returns null if not found
    public Competitor getCompetitorWithScores(int competitorId) throws SQLException {
        
        // First get basic competitor info
        Competitor competitor = getCompetitor(competitorId);
        
        if (competitor != null) {
            String query = "SELECT score1, score2, score3, score4, score5, " +
                          "score6, score7, score8, score9, score10 " +
                          "FROM competitors WHERE competitor_id = ?";
            
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, competitorId);
                
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        // Individual scores can be fetched here if needed
                        // Example: int score1 = resultSet.getInt("score1");
                    }
                }
            }
        }
        
        return competitor;
    }

    // Gets top competitors sorted by high score
    // Limit parameter controls how many to return
    public List<Competitor> getHighScores(int limit) throws SQLException {
        
        List<Competitor> competitors = new ArrayList<>();
        
        String query = "SELECT competitor_id, name, age, level, highscore " +
                      "FROM competitors ORDER BY highscore DESC LIMIT ?";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, limit);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                // Loop through all results
                while (resultSet.next()) {
                    int competitorId = resultSet.getInt("competitor_id");
                    String name = resultSet.getString("name");
                    int age = resultSet.getInt("age");
                    String level = resultSet.getString("level");
                    int highScore = resultSet.getInt("highscore");
                    
                    competitors.add(new Competitor(competitorId, name, age, level, highScore));
                }
            }
        }
        
        return competitors;
    }

    // Updates score for a specific question number (1-10)
    public void updateScore(int competitorId, int questionNumber, int score) throws SQLException {
        
        // Build column name like score1, score2, etc.
        String columnName = "score" + questionNumber;
        String query = "UPDATE competitors SET " + columnName + " = ? WHERE competitor_id = ?";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, score);
            statement.setInt(2, competitorId);
            statement.executeUpdate();
        }
    }
}