package QuizSystem;

import org.junit.jupiter.api.*;
import java.sql.*;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

// Test class for CompetitorDAO and QuestionDAO
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class DAOTest {

    // Database connection settings
    private static final String DB_URL = "jdbc:mysql://localhost:3306/quiz_management";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    // Database objects
    private Connection connection;
    private CompetitorDAO competitorDAO;
    private QuestionDAO questionDAO;

    // Runs before each test - sets up database connection
    @BeforeEach
    public void setUp() throws SQLException {
        connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        connection.setAutoCommit(false); // Start transaction

        competitorDAO = new CompetitorDAO(connection);
        questionDAO = new QuestionDAO(connection);
    }

    // Runs after each test - rolls back changes and closes connection
    @AfterEach
    public void tearDown() throws SQLException {
        connection.rollback(); // Undo all changes made during test
        connection.close();
    }

    // Test: Create a competitor and retrieve it
    @Test
    public void testCreateAndGetCompetitor() throws SQLException {
        // Create new competitor
        int id = competitorDAO.createCompetitor("Test User", 25);
        assertNotEquals(-1, id, "Competitor creation failed");

        // Get the competitor back
        Competitor competitor = competitorDAO.getCompetitorWithScores(id);
        
        // Check if data matches
        assertNotNull(competitor, "Competitor not found in database");
        assertEquals("Test User", competitor.getName(), "Competitor name mismatch");
        assertEquals(25, competitor.getAge(), "Competitor age mismatch");
    }

    // Test: Getting non-existing competitor returns null
    @Test
    public void testGetCompetitorWithScores_NotFound() throws SQLException {
        Competitor competitor = competitorDAO.getCompetitorWithScores(9999);
        assertNull(competitor, "Non-existing competitor should return null");
    }

    // Test: Update high score works correctly
    @Test
    public void testUpdateHighScore() throws SQLException {
        // Create competitor and update score
        int id = competitorDAO.createCompetitor("Test User 2", 30);
        competitorDAO.updateHighScore(id, 15);

        // Check if score was updated
        Competitor competitor = competitorDAO.getCompetitorWithScores(id);
        assertEquals(15, competitor.getHighScore(), "High score update failed");
    }

    // Test: Get high scores returns sorted list
    @Test
    public void testGetHighScores() throws SQLException {
        List<Competitor> highScores = competitorDAO.getHighScores(3);
        assertNotNull(highScores, "High scores retrieval failed");

        // Check if scores are sorted in descending order
        if (!highScores.isEmpty()) {
            for (int i = 0; i < highScores.size() - 1; i++) {
                assertTrue(
                    highScores.get(i).getHighScore() >= highScores.get(i + 1).getHighScore(),
                    "High scores are not sorted correctly"
                );
            }
        }
    }

    // Test: Add a question and retrieve it
    @Test
    public void testAddAndGetQuestion() throws SQLException {
        // Create and add question
        String[] options = {"Option 1", "Option 2", "Option 3"};
        Question question = new Question(0, "Test Question", options, 0, "beginner");
        questionDAO.addQuestion(question);

        // Get questions and find our test question
        List<Question> retrievedQuestions = questionDAO.getQuestions("beginner");
        assertFalse(retrievedQuestions.isEmpty(), "No questions retrieved from database");

        // Find the question we just added
        Question retrievedQuestion = retrievedQuestions.stream()
                .filter(q -> q.getQuestionText().equals("Test Question"))
                .findFirst()
                .orElseThrow(() -> new AssertionError("Inserted question not found"));

        // Check if all data matches
        assertEquals("Test Question", retrievedQuestion.getQuestionText(), "Question text mismatch");
        assertArrayEquals(options, retrievedQuestion.getOptions(), "Options mismatch");
        assertEquals(0, retrievedQuestion.getCorrectAnswerIndex(), "Correct answer index mismatch");
        assertEquals("beginner", retrievedQuestion.getLevel(), "Question level mismatch");
    }

    // Test: Update a question works correctly
    @Test
    public void testUpdateQuestion() throws SQLException {
        // Add initial question
        String[] initialOptions = {"Option 1", "Option 2", "Option 3"};
        Question question = new Question(0, "Test Question", initialOptions, 0, "beginner");
        questionDAO.addQuestion(question);

        // Get the question ID
        List<Question> retrievedQuestions = questionDAO.getQuestions("beginner");
        Question retrievedQuestion = retrievedQuestions.get(0);
        int questionId = retrievedQuestion.getQuestionId();

        // Update the question
        String[] updatedOptions = {"Updated Option 1", "Updated Option 2", "Updated Option 3"};
        Question updatedQuestion = new Question(
            questionId, 
            "Updated Question Text", 
            updatedOptions, 
            1, 
            "intermediate"
        );
        questionDAO.updateQuestion(updatedQuestion);

        // Get updated question and verify
        List<Question> finalQuestions = questionDAO.getQuestions("intermediate");
        assertFalse(finalQuestions.isEmpty(), "Updated question not found");

        Question finalQuestion = finalQuestions.get(0);
        assertEquals("Updated Question Text", finalQuestion.getQuestionText(), "Updated question text mismatch");
        assertArrayEquals(updatedOptions, finalQuestion.getOptions(), "Updated options mismatch");
        assertEquals(1, finalQuestion.getCorrectAnswerIndex(), "Updated answer index mismatch");
        assertEquals("intermediate", finalQuestion.getLevel(), "Updated question level mismatch");
    }

    // Test: Delete a question works correctly
    @Test
    public void testDeleteQuestion() throws SQLException {
        // Add a question to delete
        String[] options = {"Option 1", "Option 2", "Option 3"};
        Question question = new Question(0, "Test Delete Question", options, 0, "beginner");
        questionDAO.addQuestion(question);

        // Find the question we just added
        List<Question> retrievedQuestions = questionDAO.getQuestions("beginner");
        Question retrievedQuestion = retrievedQuestions.stream()
                .filter(q -> q.getQuestionText().equals("Test Delete Question"))
                .findFirst()
                .orElseThrow(() -> new AssertionError("Inserted question not found"));

        int questionId = retrievedQuestion.getQuestionId();

        // Delete the question
        questionDAO.deleteQuestion(questionId);

        // Check if question is really deleted
        List<Question> finalQuestions = questionDAO.getQuestions("beginner");
        boolean questionExists = finalQuestions.stream()
                .anyMatch(q -> q.getQuestionId() == questionId);

        assertFalse(questionExists, "Deleted question still exists in database");
    }
}