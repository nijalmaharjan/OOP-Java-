package QuizSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

// Main class - entry point for the console-based Quiz Application
public class Main {
    
    // Database connection settings
    private static final String DB_URL = "jdbc:mysql://localhost:3306/quiz_management";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    
    // Database connection object
    private static Connection connection;

    // Main method - starts the application
    public static void main(String[] args) {
        try {
            // Connect to database
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // Create DAO objects for database operations
            CompetitorDAO competitorDAO = new CompetitorDAO(connection);
            QuestionDAO questionDAO = new QuestionDAO(connection);
            Scanner scanner = new Scanner(System.in);
            int choice;

            System.out.println("Welcome to the Quiz Application!");

            // Main menu loop
            do {
                displayMenu();
                System.out.print("Enter your choice: ");
                
                // Validate input
                while (!scanner.hasNextInt()) {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.next();
                    System.out.print("Enter your choice: ");
                }
                
                choice = scanner.nextInt();
                scanner.nextLine(); // Clear buffer

                switch (choice) {
                    case 1:
                        startQuiz(scanner, competitorDAO, questionDAO);
                        break;
                    case 2:
                        getPlayerDetails(scanner, competitorDAO);
                        break;
                    case 3:
                        getHighscores(competitorDAO);
                        break;
                    case 4:
                        adminPanel(scanner);
                        break;
                    case 5:
                        System.out.println("Thank you for using Quiz Application. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } while (choice != 5);

            // Clean up
            scanner.close();
            connection.close();
            
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }
    }

    // Shows the main menu
    private static void displayMenu() {
        System.out.println("\nQuiz Application Menu:");
        System.out.println("1. Start Quiz");
        System.out.println("2. Get Player Details");
        System.out.println("3. Get Highscores");
        System.out.println("4. Admin Panel");
        System.out.println("5. Exit");
    }

    // Starts the quiz for a player
    private static void startQuiz(Scanner scanner, CompetitorDAO competitorDAO, QuestionDAO questionDAO) {
        try {
            // Get player name
            System.out.print("Enter your name: ");
            String name = scanner.nextLine().trim();
            
            if (name.isEmpty()) {
                System.out.println("Name cannot be empty.");
                return;
            }

            // Get player age
            System.out.print("Enter your age: ");
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
                System.out.print("Enter your age: ");
            }
            int age = scanner.nextInt();
            scanner.nextLine();

            // Check if player exists or create new
            int competitorId = competitorDAO.getCompetitorId(name, age);
            if (competitorId == -1) {
                competitorId = competitorDAO.createCompetitor(name, age);
                System.out.println("Welcome, " + name + "! Your competitor ID is: " + competitorId);
            } else {
                System.out.println("Welcome back, " + name + "! Your competitor ID is: " + competitorId);
            }

            // Select difficulty level
            String level = selectLevel(scanner);
            if (level == null) {
                return;
            }
            
            // Update player's level
            competitorDAO.updateLevel(competitorId, level);

            // Get questions for selected level
            List<Question> questions = questionDAO.getQuestions(level);
            
            if (questions.isEmpty()) {
                System.out.println("No questions available for this level.");
                return;
            }

            // Start the quiz
            int score = 0;
            int questionNumber = 0;

            System.out.println("\nStarting Quiz - " + level.toUpperCase() + " Level");
            System.out.println("Total Questions: " + questions.size() + "\n");

            // Loop through each question
            for (Question question : questions) {
                questionNumber++;
                System.out.println("Question " + questionNumber + ": " + question.getQuestionText());
                
                // Display options
                String[] options = question.getOptions();
                for (int i = 0; i < options.length; i++) {
                    System.out.println("  " + (i + 1) + ". " + options[i]);
                }

                // Get answer from user
                System.out.print("Your answer (1-" + options.length + "): ");
                int answer = -1;
                
                while (answer < 1 || answer > options.length) {
                    while (!scanner.hasNextInt()) {
                        System.out.println("Invalid input. Please enter a number.");
                        scanner.next();
                        System.out.print("Your answer (1-" + options.length + "): ");
                    }
                    answer = scanner.nextInt();
                    scanner.nextLine();
                    
                    if (answer < 1 || answer > options.length) {
                        System.out.println("Please enter a number between 1 and " + options.length);
                    }
                }

                // Check if answer is correct
                if (question.isCorrect(answer - 1)) {
                    System.out.println("Correct!\n");
                    score++;
                } else {
                    int correctIndex = question.getCorrectAnswerIndex();
                    System.out.println("Wrong! The correct answer was: " + (correctIndex + 1) + ". " + options[correctIndex] + "\n");
                }
            }

            // Show final score
            System.out.println("Quiz Complete!");
            System.out.println("Your Score: " + score + "/" + questions.size());

            // Update high score if needed
            competitorDAO.updateHighScore(competitorId, score);
            
            // Get current high score to show
            Competitor competitor = competitorDAO.getCompetitor(competitorId);
            System.out.println("Your High Score: " + competitor.getHighScore());

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }
    }

    // Lets player select difficulty level
    private static String selectLevel(Scanner scanner) {
        System.out.println("\nSelect Difficulty Level:");
        System.out.println("1. Beginner");
        System.out.println("2. Intermediate");
        System.out.println("3. Advanced");
        System.out.print("Enter your choice: ");

        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next();
            System.out.print("Enter your choice: ");
        }
        
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                return "beginner";
            case 2:
                return "intermediate";
            case 3:
                return "advanced";
            default:
                System.out.println("Invalid choice. Defaulting to Beginner.");
                return "beginner";
        }
    }

    // Shows details of a specific player
    private static void getPlayerDetails(Scanner scanner, CompetitorDAO competitorDAO) {
        System.out.print("Enter Competitor ID: ");
        
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next();
            System.out.print("Enter Competitor ID: ");
        }
        
        int competitorId = scanner.nextInt();
        scanner.nextLine();

        try {
            Competitor competitor = competitorDAO.getCompetitorWithScores(competitorId);
            
            if (competitor != null) {
                System.out.println("\nPlayer Details:");
                System.out.println(competitor.toString());
            } else {
                System.out.println("Competitor with ID " + competitorId + " not found.");
            }
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }
    }

    // Shows top high scores
    private static void getHighscores(CompetitorDAO competitorDAO) {
        try {
            List<Competitor> highScores = competitorDAO.getHighScores(10);
            
            if (highScores.isEmpty()) {
                System.out.println("No high scores recorded yet.");
            } else {
                System.out.println("\nTop 10 High Scores:");
                System.out.println("Rank | Name                | Level        | Score");
                
                int rank = 1;
                for (Competitor competitor : highScores) {
                    String level = competitor.getLevel();
                    if (level == null) {
                        level = "N/A";
                    }
                    
                    System.out.printf("%4d | %-19s | %-12s | %d%n",
                        rank,
                        competitor.getName(),
                        level,
                        competitor.getHighScore()
                    );
                    rank++;
                }
            }
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }
    }

    // Opens the admin panel
    private static void adminPanel(Scanner scanner) {
        // Ask for admin password
        System.out.print("Enter admin password: ");
        String password = scanner.nextLine();

        if (!password.equals("admin123")) {
            System.out.println("Incorrect password. Access denied.");
            return;
        }

        // Run admin panel from Admin class
        try {
            Admin.runAdminPanel(scanner, connection);
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }
    }
}