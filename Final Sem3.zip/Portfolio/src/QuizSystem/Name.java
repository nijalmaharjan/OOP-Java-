package QuizSystem;

// Name class - stores first and last name with helper methods
public class Name {
    
    private String firstName;
    private String lastName;
    
    // Constructor with first and last name
    public Name(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
    
    // Constructor with full name (splits by space)
    public Name(String fullName) {
        if (fullName != null && !fullName.trim().isEmpty()) {
            String[] parts = fullName.trim().split(" ");
            this.firstName = parts[0];
            if (parts.length > 1) {
                this.lastName = parts[parts.length - 1];
            } else {
                this.lastName = "";
            }
        } else {
            this.firstName = "";
            this.lastName = "";
        }
    }
    
    // Returns first name
    public String getFirstName() {
        return firstName;
    }
    
    // Returns last name
    public String getLastName() {
        return lastName;
    }
    
    // Returns full name
    public String getFullName() {
        if (lastName == null || lastName.isEmpty()) {
            return firstName;
        }
        return firstName + " " + lastName;
    }
    
    // Returns initials (e.g., "JD" for John Doe)
    public String getInitials() {
        String initials = "";
        
        if (firstName != null && !firstName.isEmpty()) {
            initials += Character.toUpperCase(firstName.charAt(0));
        }
        
        if (lastName != null && !lastName.isEmpty()) {
            initials += Character.toUpperCase(lastName.charAt(0));
        }
        
        return initials;
    }
    
    // Sets first name
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    // Sets last name
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    // Returns full name as string
    @Override
    public String toString() {
        return getFullName();
    }
}