package QuizSystem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// QuestionDAO class - handles all database operations for questions
public class QuestionDAO {
    
    // Database connection
    private Connection connection;

    // Constructor - takes database connection as parameter
    public QuestionDAO(Connection connection) {
        this.connection = connection;
    }

    // Gets all questions for a specific difficulty level
    // Returns empty list if no questions found
    public List<Question> getQuestions(String level) throws SQLException {
        
        List<Question> questions = new ArrayList<>();
        
        String query = "SELECT question_id, question_text, option1, option2, option3, " +
                       "correct_answer, level FROM questions WHERE level = ?";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, level);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Question question = extractQuestionFromResultSet(resultSet);
                    questions.add(question);
                }
            }
        }
        
        return questions;
    }

    // Gets all questions from database
    public List<Question> getAllQuestions() throws SQLException {
        
        List<Question> questions = new ArrayList<>();
        
        String query = "SELECT question_id, question_text, option1, option2, option3, " +
                       "correct_answer, level FROM questions";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Question question = extractQuestionFromResultSet(resultSet);
                    questions.add(question);
                }
            }
        }
        
        return questions;
    }

    // Gets a single question by its ID
    // Returns null if not found
    public Question getQuestionById(int questionId) throws SQLException {
        
        String query = "SELECT question_id, question_text, option1, option2, option3, " +
                       "correct_answer, level FROM questions WHERE question_id = ?";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, questionId);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return extractQuestionFromResultSet(resultSet);
                }
            }
        }
        
        return null;
    }

    // Adds a new question to the database
    public void addQuestion(Question question) throws SQLException {
        
        String query = "INSERT INTO questions (question_text, option1, option2, option3, " +
                       "correct_answer, level) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            // Set question text
            statement.setString(1, question.getQuestionText());
            
            // Set options
            String[] options = question.getOptions();
            statement.setString(2, options[0]);
            statement.setString(3, options[1]);
            statement.setString(4, options[2]);
            
            // Set correct answer (convert to 1-based for database)
            statement.setInt(5, question.getCorrectAnswerIndex() + 1);
            
            // Set level
            statement.setString(6, question.getLevel());
            
            statement.executeUpdate();
        }
    }

    // Updates an existing question in the database
    public void updateQuestion(Question question) throws SQLException {
        
        String query = "UPDATE questions SET question_text = ?, option1 = ?, option2 = ?, " +
                       "option3 = ?, correct_answer = ?, level = ? WHERE question_id = ?";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            // Set question text
            statement.setString(1, question.getQuestionText());
            
            // Set options
            String[] options = question.getOptions();
            statement.setString(2, options[0]);
            statement.setString(3, options[1]);
            statement.setString(4, options[2]);
            
            // Set correct answer (convert to 1-based for database)
            statement.setInt(5, question.getCorrectAnswerIndex() + 1);
            
            // Set level
            statement.setString(6, question.getLevel());
            
            // Set question ID for WHERE clause
            statement.setInt(7, question.getQuestionId());
            
            statement.executeUpdate();
        }
    }

    // Deletes a question from the database by ID
    public void deleteQuestion(int questionId) throws SQLException {
        
        String query = "DELETE FROM questions WHERE question_id = ?";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, questionId);
            statement.executeUpdate();
        }
    }

    // Helper method - extracts question data from database result
    // Used by getQuestions, getAllQuestions, and getQuestionById
    private Question extractQuestionFromResultSet(ResultSet resultSet) throws SQLException {
        
        int questionId = resultSet.getInt("question_id");
        String questionText = resultSet.getString("question_text");
        
        // Get options
        String[] options = {
            resultSet.getString("option1"),
            resultSet.getString("option2"),
            resultSet.getString("option3")
        };
        
        // Convert from 1-based (database) to 0-based (code)
        int correctAnswerIndex = resultSet.getInt("correct_answer") - 1;
        
        String level = resultSet.getString("level");
        
        return new Question(questionId, questionText, options, correctAnswerIndex, level);
    }
}