package QuizSystem;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Admin class - handles all admin operations for managing quiz questions
public class Admin {

    // Menu options
    private static final int ADD_QUESTION = 1;
    private static final int UPDATE_QUESTION = 2;
    private static final int DELETE_QUESTION = 3;
    private static final int VIEW_QUESTIONS = 4;
    private static final int BACK_TO_MAIN = 5;

    // Valid difficulty levels
    private static final String[] VALID_LEVELS = {"beginner", "intermediate", "advanced"};
    
    // Number of options per question
    private static final int NUMBER_OF_OPTIONS = 3;

    // Main method to run the admin panel
    public static void runAdminPanel(Scanner scanner, Connection connection) throws SQLException {
        
        // Create database access object
        QuestionDAO questionDAO = new QuestionDAO(connection);
        boolean running = true;

        System.out.println("        WELCOME TO ADMIN PANEL");

        // Keep showing menu until user exits
        while (running) {
            displayAdminMenu();
            int choice = getValidMenuChoice(scanner);

            try {
                switch (choice) {
                    case ADD_QUESTION:
                        addQuestion(scanner, questionDAO);
                        break;
                    case UPDATE_QUESTION:
                        updateQuestion(scanner, questionDAO);
                        break;
                    case DELETE_QUESTION:
                        deleteQuestion(scanner, questionDAO);
                        break;
                    case VIEW_QUESTIONS:
                        viewQuestions(scanner, questionDAO);
                        break;
                    case BACK_TO_MAIN:
                        System.out.println("Returning to Main Menu...");
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                System.err.println("Database Error: " + e.getMessage());
                System.out.println("Please try again.");
            }
        }
    }

    // Shows the admin menu options
    private static void displayAdminMenu() {
        System.out.println("           ADMIN MENU");
        System.out.println("1. Add Question");
        System.out.println("2. Update Question");
        System.out.println("3. Delete Question");
        System.out.println("4. View Questions");
        System.out.println("5. Back to Main Menu");
        System.out.print("Enter your choice: ");
    }

    // Gets a valid number from user input
    private static int getValidMenuChoice(Scanner scanner) {
        
        // Keep asking until user enters a valid number
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number (1-5).");
            scanner.next();
            System.out.print("Enter your choice: ");
        }
        
        int choice = scanner.nextInt();
        scanner.nextLine(); // Clear the buffer
        return choice;
    }

    // Adds a new question to the database
    private static void addQuestion(Scanner scanner, QuestionDAO questionDAO) throws SQLException {
        
        System.out.println("         ADD NEW QUESTION");

        // Get question text
        System.out.print("Enter question text: ");
        String questionText = scanner.nextLine().trim();
        
        // Check if question is empty
        if (questionText.isEmpty()) {
            System.out.println("Error: Question text cannot be empty.");
            return;
        }

        // Get 3 options from user
        List<String> optionsList = new ArrayList<>();
        for (int i = 0; i < NUMBER_OF_OPTIONS; i++) {
            System.out.print("Enter option " + (i + 1) + ": ");
            String option = scanner.nextLine().trim();
            
            // Check if option is empty
            if (option.isEmpty()) {
                System.out.println("Error: Option cannot be empty.");
                return;
            }
            optionsList.add(option);
        }

        // Convert list to array
        String[] optionsArray = optionsList.toArray(new String[0]);

        // Get correct answer index
        int correctAnswer = getCorrectAnswerIndex(scanner, optionsArray.length);
        if (correctAnswer == -1) {
            System.out.println("Operation cancelled.");
            return;
        }

        // Get difficulty level
        String difficulty = getValidDifficultyLevel(scanner);
        if (difficulty == null) {
            System.out.println("Operation cancelled.");
            return;
        }

        // Create question and save to database
        Question question = new Question(0, questionText, optionsArray, correctAnswer, difficulty);
        questionDAO.addQuestion(question);
        
        System.out.println("Question added successfully!");
        System.out.println("Level: " + difficulty);
        System.out.println("Correct Answer: Option " + (correctAnswer + 1));
    }

    // Updates an existing question in the database
    private static void updateQuestion(Scanner scanner, QuestionDAO questionDAO) throws SQLException {
        
        System.out.println("         UPDATE QUESTION");

        // Get question ID from user
        System.out.print("Enter question ID to update: ");
        if (!scanner.hasNextInt()) {
            System.out.println("Error: Invalid ID. Please enter a number.");
            scanner.nextLine();
            return;
        }
        
        int questionId = scanner.nextInt();
        scanner.nextLine();

        // Check if question exists in database
        Question existingQuestion = questionDAO.getQuestionById(questionId);
        if (existingQuestion == null) {
            System.out.println("Error: Question with ID " + questionId + " not found.");
            return;
        }

        // Show current question details
        System.out.println("\nCurrent Question Details:");
        System.out.println(existingQuestion);
        System.out.println();

        // Get new question text or keep old one
        System.out.print("Enter new question text (or press Enter to keep current): ");
        String questionText = scanner.nextLine().trim();
        if (questionText.isEmpty()) {
            questionText = existingQuestion.getQuestionText();
        }

        // Get new options or keep old ones
        String[] options = new String[NUMBER_OF_OPTIONS];
        System.out.println("\nEnter new options (or press Enter to keep current):");
        
        for (int i = 0; i < NUMBER_OF_OPTIONS; i++) {
            System.out.print("Option " + (i + 1) + " [" + existingQuestion.getOptions()[i] + "]: ");
            String option = scanner.nextLine().trim();
            
            // Keep old option if user presses enter
            if (option.isEmpty()) {
                options[i] = existingQuestion.getOptions()[i];
            } else {
                options[i] = option;
            }
        }

        // Get correct answer or keep old one
        System.out.print("\nEnter correct answer (1-" + NUMBER_OF_OPTIONS + ") [Current: " + 
                        (existingQuestion.getCorrectAnswerIndex() + 1) + "]: ");
        
        int correctAnswer;
        if (scanner.hasNextInt()) {
            correctAnswer = scanner.nextInt() - 1;
            scanner.nextLine();
            
            // Check if answer is valid
            if (correctAnswer < 0 || correctAnswer >= NUMBER_OF_OPTIONS) {
                System.out.println("Invalid answer. Keeping current value.");
                correctAnswer = existingQuestion.getCorrectAnswerIndex();
            }
        } else {
            scanner.nextLine();
            correctAnswer = existingQuestion.getCorrectAnswerIndex();
        }

        // Get difficulty level or keep old one
        System.out.print("Enter difficulty (beginner/intermediate/advanced) [Current: " + 
                        existingQuestion.getLevel() + "]: ");
        String difficulty = scanner.nextLine().trim().toLowerCase();
        
        if (difficulty.isEmpty() || !isValidLevel(difficulty)) {
            if (!difficulty.isEmpty()) {
                System.out.println("Invalid level. Keeping current value.");
            }
            difficulty = existingQuestion.getLevel();
        }

        // Ask user to confirm update
        System.out.print("\nConfirm update? (yes/no): ");
        String confirm = scanner.nextLine().trim().toLowerCase();
        
        if (confirm.equals("yes") || confirm.equals("y")) {
            // Save updated question
            Question updatedQuestion = new Question(questionId, questionText, options, correctAnswer, difficulty);
            questionDAO.updateQuestion(updatedQuestion);
            System.out.println("Question updated successfully!");
        } else {
            System.out.println("Update cancelled.");
        }
    }

    // Deletes a question from the database
    private static void deleteQuestion(Scanner scanner, QuestionDAO questionDAO) throws SQLException {
        
        System.out.println("         DELETE QUESTION");

        // Get question ID from user
        System.out.print("Enter question ID to delete: ");
        if (!scanner.hasNextInt()) {
            System.out.println("Error: Invalid ID. Please enter a number.");
            scanner.nextLine();
            return;
        }
        
        int questionId = scanner.nextInt();
        scanner.nextLine();

        // Check if question exists
        Question question = questionDAO.getQuestionById(questionId);
        if (question == null) {
            System.out.println("Error: Question with ID " + questionId + " not found.");
            return;
        }

        // Show question that will be deleted
        System.out.println("\nQuestion to be deleted:");
        System.out.println(question);

        // Ask user to confirm deletion
        System.out.print("\nAre you sure you want to delete this question? (yes/no): ");
        String confirm = scanner.nextLine().trim().toLowerCase();

        if (confirm.equals("yes") || confirm.equals("y")) {
            questionDAO.deleteQuestion(questionId);
            System.out.println("Question deleted successfully!");
        } else {
            System.out.println("Deletion cancelled.");
        }
    }

    // Shows questions with filtering options
    private static void viewQuestions(Scanner scanner, QuestionDAO questionDAO) throws SQLException {
        
        System.out.println("         VIEW QUESTIONS");
        System.out.println("1. View All Questions");
        System.out.println("2. View Beginner Questions");
        System.out.println("3. View Intermediate Questions");
        System.out.println("4. View Advanced Questions");
        System.out.print("Enter your choice: ");

        int choice = getValidMenuChoice(scanner);
        List<Question> questions;

        // Get questions based on user choice
        switch (choice) {
            case 1:
                questions = questionDAO.getAllQuestions();
                displayQuestionList(questions, "All Questions");
                break;
            case 2:
                questions = questionDAO.getQuestions("beginner");
                displayQuestionList(questions, "Beginner Level Questions");
                break;
            case 3:
                questions = questionDAO.getQuestions("intermediate");
                displayQuestionList(questions, "Intermediate Level Questions");
                break;
            case 4:
                questions = questionDAO.getQuestions("advanced");
                displayQuestionList(questions, "Advanced Level Questions");
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    // Displays a list of questions in a nice format
    private static void displayQuestionList(List<Question> questions, String title) {
        
        System.out.println("  " + title);

        // Check if there are any questions
        if (questions.isEmpty()) {
            System.out.println("  No questions available.");
        } else {
            System.out.println("  Total Questions: " + questions.size() + "\n");
            
            // Loop through and display each question
            int count = 1;
            for (Question question : questions) {
                System.out.println("---- Question #" + count + " ----");
                System.out.println(question);
                System.out.println();
                count++;
            }
        }
        
    }

    // Gets a valid correct answer index from user
    private static int getCorrectAnswerIndex(Scanner scanner, int numberOfOptions) {
        
        int attempts = 0;
        int maxAttempts = 3;

        // Try up to 3 times
        while (attempts < maxAttempts) {
            System.out.print("Enter correct answer (1-" + numberOfOptions + "): ");
            
            if (scanner.hasNextInt()) {
                int answer = scanner.nextInt() - 1; // Convert to 0-based index
                scanner.nextLine();
                
                // Check if answer is in valid range
                if (answer >= 0 && answer < numberOfOptions) {
                    return answer;
                } else {
                    System.out.println("Error: Please enter a number between 1 and " + numberOfOptions);
                }
            } else {
                String input = scanner.nextLine();
                
                // Allow user to cancel
                if (input.equalsIgnoreCase("cancel")) {
                    return -1;
                }
                System.out.println("Error: Invalid input. Please enter a number.");
            }
            
            attempts++;
        }

        System.out.println("Too many invalid attempts.");
        return -1;
    }

    // Gets a valid difficulty level from user
    private static String getValidDifficultyLevel(Scanner scanner) {
        
        int attempts = 0;
        int maxAttempts = 3;

        // Try up to 3 times
        while (attempts < maxAttempts) {
            System.out.print("Enter difficulty level (beginner/intermediate/advanced): ");
            String level = scanner.nextLine().trim().toLowerCase();

            // Allow user to cancel
            if (level.equalsIgnoreCase("cancel")) {
                return null;
            }

            // Check if level is valid
            if (isValidLevel(level)) {
                return level;
            } else {
                System.out.println("Error: Invalid level. Please enter: beginner, intermediate, or advanced");
            }

            attempts++;
        }

        System.out.println("Too many invalid attempts.");
        return null;
    }

    // Checks if the given level is valid
    private static boolean isValidLevel(String level) {
        
        // Return false if level is null or empty
        if (level == null || level.isEmpty()) {
            return false;
        }

        // Check against valid levels
        for (String validLevel : VALID_LEVELS) {
            if (validLevel.equalsIgnoreCase(level)) {
                return true;
            }
        }
        
        return false;
    }
}