package QuizSystem;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

/**
 * QuizGUI — Main GUI application for the Quiz Management System.
 * Layout: fixed dark sidebar (navigation) + dynamic content panel (CardLayout).
 */
public class QuizGUI extends JFrame {

    // ─── Database Config ────────────────────────────────────────────────────────
    private static final String DB_URL      = "jdbc:mysql://localhost:3306/quiz_management";
    private static final String DB_USER     = "root";
    private static final String DB_PASSWORD = "";

    // ─── Admin Credentials ──────────────────────────────────────────────────────
    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin123";

    // ─── Theme Colors ───────────────────────────────────────────────────────────
    private static final Color SIDEBAR_BG      = new Color(0x1E2A3A);
    private static final Color SIDEBAR_HOVER   = new Color(0x2A3D54);
    private static final Color SIDEBAR_ACTIVE  = new Color(0x3D9BE9);
    private static final Color CONTENT_BG      = new Color(0xF0F2F5);
    private static final Color ACCENT_BLUE     = new Color(0x3D9BE9);
    private static final Color ACCENT_DARK     = new Color(0x1E2A3A);
    private static final Color TEXT_LIGHT      = new Color(0xFFFFFF);
    private static final Color TEXT_DARK       = new Color(0x2C3E50);
    private static final Color TEXT_MUTED      = new Color(0x7F8C8D);
    private static final Color CARD_BG         = new Color(0xFFFFFF);
    private static final Color BORDER_COLOR    = new Color(0xDDE1E7);
    private static final Color SUCCESS_COLOR   = new Color(0x27AE60);
    private static final Color DANGER_COLOR    = new Color(0xE74C3C);

    // ─── Fonts ──────────────────────────────────────────────────────────────────
    private static final Font FONT_TITLE   = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_HEADING = new Font("Segoe UI", Font.BOLD, 16);
    private static final Font FONT_BODY    = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font FONT_SMALL   = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font FONT_MONO    = new Font("Consolas", Font.PLAIN, 13);
    private static final Font FONT_NAV     = new Font("Segoe UI", Font.BOLD, 13);
    private static final Font FONT_LOGO    = new Font("Segoe UI", Font.BOLD, 15);

    // ─── DAOs ───────────────────────────────────────────────────────────────────
    private Connection    connection;
    private CompetitorDAO competitorDAO;
    private QuestionDAO   questionDAO;

    // ─── Layout ─────────────────────────────────────────────────────────────────
    private JPanel    contentPanel;   // right side — CardLayout
    private CardLayout contentLayout;
    private JButton   activeNavBtn;

    // ─── Content Panels ─────────────────────────────────────────────────────────
    private JPanel homePanel;
    private JPanel quizPanel;
    private JPanel playerDetailsPanel;
    private JPanel highscoresPanel;
    private JPanel adminPanel;

    // ─── Quiz State ─────────────────────────────────────────────────────────────
    private List<Question> questions;
    private int  currentQuestionIndex;
    private int  score;
    private int  competitorId;
    private String competitorName;

    // ─── Quiz UI ────────────────────────────────────────────────────────────────
    private JLabel      scoreLabel;
    private JLabel      progressLabel;
    private JTextArea   questionArea;
    private JRadioButton[] optionBtns;
    private ButtonGroup optionGroup;
    private JProgressBar quizProgress;

    // ─── Admin Sub-panels ───────────────────────────────────────────────────────
    private JPanel     adminContent;
    private CardLayout adminLayout;
    private JTextArea  viewQuestionsArea;

    // ════════════════════════════════════════════════════════════════════════════
    //  Constructor
    // ════════════════════════════════════════════════════════════════════════════
    public QuizGUI() {
        setupFrame();
        initDatabase();
        buildUI();
        setVisible(true);
    }

    // ─── Frame Setup ────────────────────────────────────────────────────────────
    private void setupFrame() {
        setTitle("Quiz Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 660);
        setMinimumSize(new Dimension(800, 560));
        setLocationRelativeTo(null);
    }

    // ─── Database Init ──────────────────────────────────────────────────────────
    private void initDatabase() {
        try {
            connection    = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            competitorDAO = new CompetitorDAO(connection);
            questionDAO   = new QuestionDAO(connection);
        } catch (SQLException e) {
            showError("Database Connection Failed", e.getMessage());
            System.exit(1);
        }
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Master Layout Builder
    // ════════════════════════════════════════════════════════════════════════════
    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.add(buildSidebar(), BorderLayout.WEST);

        contentLayout = new CardLayout();
        contentPanel  = new JPanel(contentLayout);
        contentPanel.setBackground(CONTENT_BG);

        buildHomePanel();
        buildQuizPanel();
        buildPlayerDetailsPanel();
        buildHighscoresPanel();
        buildAdminPanel();

        contentPanel.add(homePanel,          "home");
        contentPanel.add(quizPanel,          "quiz");
        contentPanel.add(playerDetailsPanel, "playerDetails");
        contentPanel.add(highscoresPanel,    "highscores");
        contentPanel.add(adminPanel,         "admin");

        root.add(contentPanel, BorderLayout.CENTER);
        setContentPane(root);
        contentLayout.show(contentPanel, "home");
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Sidebar
    // ════════════════════════════════════════════════════════════════════════════
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(SIDEBAR_BG);
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(200, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        // Logo area
        JPanel logoPanel = new JPanel(new BorderLayout());
        logoPanel.setBackground(new Color(0x16202E));
        logoPanel.setMaximumSize(new Dimension(200, 70));
        logoPanel.setPreferredSize(new Dimension(200, 70));
        logoPanel.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        JLabel logoLabel = new JLabel("QUIZ SYSTEM");
        logoLabel.setFont(FONT_LOGO);
        logoLabel.setForeground(TEXT_LIGHT);
        logoPanel.add(logoLabel, BorderLayout.CENTER);
        sidebar.add(logoPanel);

        // Divider
        sidebar.add(makeSidebarDivider());

        // Nav buttons
        JButton homeBtn    = makeNavButton("  Home",           "home");
        JButton quizBtn    = makeNavButton("  Start Quiz",     "startQuiz");
        JButton detailsBtn = makeNavButton("  Player Details", "playerDetails");
        JButton scoresBtn  = makeNavButton("  Highscores",     "highscores");
        JButton adminBtn   = makeNavButton("  Admin",          "adminLogin");

        sidebar.add(homeBtn);
        sidebar.add(detailsBtn);
        sidebar.add(scoresBtn);
        sidebar.add(quizBtn);
        sidebar.add(adminBtn);
        sidebar.add(Box.createVerticalGlue());

        // Exit button at bottom
        sidebar.add(makeSidebarDivider());
        JButton exitBtn = makeNavButton("  Exit", "exit");
        exitBtn.setForeground(new Color(0xFF6B6B));
        sidebar.add(exitBtn);
        sidebar.add(Box.createRigidArea(new Dimension(0, 12)));

        // Set home as default active
        setActiveNavButton(homeBtn);
        activeNavBtn = homeBtn;

        return sidebar;
    }

    private JPanel makeSidebarDivider() {
        JPanel div = new JPanel();
        div.setBackground(new Color(0x2A3D54));
        div.setMaximumSize(new Dimension(200, 1));
        div.setPreferredSize(new Dimension(200, 1));
        return div;
    }

    private JButton makeNavButton(String text, String action) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getClientProperty("active") != null && (boolean) getClientProperty("active")) {
                    g2.setColor(ACCENT_BLUE);
                    g2.fillRect(0, 0, 4, getHeight());
                    g2.setColor(SIDEBAR_HOVER);
                    g2.fillRect(4, 0, getWidth() - 4, getHeight());
                } else if (getModel().isRollover()) {
                    g2.setColor(SIDEBAR_HOVER);
                    g2.fillRect(0, 0, getWidth(), getHeight());
                } else {
                    g2.setColor(SIDEBAR_BG);
                    g2.fillRect(0, 0, getWidth(), getHeight());
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(FONT_NAV);
        btn.setForeground(new Color(0xBDC3CC));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setMaximumSize(new Dimension(200, 52));
        btn.setPreferredSize(new Dimension(200, 52));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 10));

        btn.addActionListener(e -> handleNavAction(action, btn));
        return btn;
    }

    private void setActiveNavButton(JButton btn) {
        if (activeNavBtn != null) {
            activeNavBtn.putClientProperty("active", false);
            activeNavBtn.setForeground(new Color(0xBDC3CC));
            activeNavBtn.repaint();
        }
        btn.putClientProperty("active", true);
        btn.setForeground(TEXT_LIGHT);
        btn.repaint();
        activeNavBtn = btn;
    }

    private void handleNavAction(String action, JButton sourceBtn) {
        switch (action) {
            case "home":
                setActiveNavButton(sourceBtn);
                contentLayout.show(contentPanel, "home");
                break;
            case "startQuiz":
                setActiveNavButton(sourceBtn);
                showPlayerInfoDialog();
                break;
            case "playerDetails":
                setActiveNavButton(sourceBtn);
                contentLayout.show(contentPanel, "playerDetails");
                break;
            case "highscores":
                setActiveNavButton(sourceBtn);
                loadAndShowHighscores();
                break;
            case "adminLogin":
                showAdminLoginDialog(sourceBtn);
                break;
            case "exit":
                closeApp();
                break;
        }
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Home Panel
    // ════════════════════════════════════════════════════════════════════════════
    private void buildHomePanel() {
        homePanel = new JPanel(new BorderLayout());
        homePanel.setBackground(CONTENT_BG);

        // Content header
        homePanel.add(makeContentHeader("Home", "Welcome to the Quiz System"), BorderLayout.NORTH);

        // Center welcome card
        JPanel center = new JPanel(new GridBagLayout());
        center.setBackground(CONTENT_BG);

        JPanel card = makeCard();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(40, 50, 40, 50));
        card.setMaximumSize(new Dimension(520, 340));
        card.setPreferredSize(new Dimension(520, 340));

        JLabel icon = new JLabel("🎓", SwingConstants.CENTER);
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 56));
        icon.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("Welcome to the Quiz System", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(TEXT_DARK);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("<html><center>Test your knowledge across multiple levels.<br>Compete with others and track your highscores.</center></html>", SwingConstants.CENTER);
        subtitle.setFont(FONT_BODY);
        subtitle.setForeground(TEXT_MUTED);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton startBtn = makePrimaryButton("Start Quiz Now →");
        startBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        startBtn.addActionListener(e -> showPlayerInfoDialog());

        card.add(icon);
        card.add(Box.createRigidArea(new Dimension(0, 16)));
        card.add(title);
        card.add(Box.createRigidArea(new Dimension(0, 10)));
        card.add(subtitle);
        card.add(Box.createRigidArea(new Dimension(0, 26)));
        card.add(startBtn);

        center.add(card);
        homePanel.add(center, BorderLayout.CENTER);
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Quiz Panel
    // ════════════════════════════════════════════════════════════════════════════
    private void buildQuizPanel() {
        quizPanel = new JPanel(new BorderLayout());
        quizPanel.setBackground(CONTENT_BG);
        quizPanel.add(makeContentHeader("Quiz", "Answer the questions below"), BorderLayout.NORTH);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(CONTENT_BG);

        JPanel card = makeCard();
        card.setLayout(new BorderLayout(0, 16));
        card.setPreferredSize(new Dimension(620, 420));
        card.setBorder(BorderFactory.createEmptyBorder(28, 32, 28, 32));

        // Top: score + progress
        JPanel topBar = new JPanel(new BorderLayout(10, 0));
        topBar.setOpaque(false);
        scoreLabel    = makeLabel("Score: 0", FONT_HEADING, ACCENT_BLUE);
        progressLabel = makeLabel("Question 1 / 10", FONT_BODY, TEXT_MUTED);
        topBar.add(scoreLabel,    BorderLayout.WEST);
        topBar.add(progressLabel, BorderLayout.EAST);

        quizProgress = new JProgressBar(0, 100);
        quizProgress.setValue(0);
        quizProgress.setBackground(BORDER_COLOR);
        quizProgress.setForeground(ACCENT_BLUE);
        quizProgress.setBorderPainted(false);
        quizProgress.setPreferredSize(new Dimension(0, 6));

        JPanel topSection = new JPanel(new BorderLayout(0, 8));
        topSection.setOpaque(false);
        topSection.add(topBar,       BorderLayout.NORTH);
        topSection.add(quizProgress, BorderLayout.SOUTH);
        card.add(topSection, BorderLayout.NORTH);

        // Question text
        questionArea = new JTextArea();
        questionArea.setEditable(false);
        questionArea.setLineWrap(true);
        questionArea.setWrapStyleWord(true);
        questionArea.setFont(new Font("Segoe UI", Font.BOLD, 16));
        questionArea.setForeground(TEXT_DARK);
        questionArea.setBackground(new Color(0xF8F9FA));
        questionArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
            BorderFactory.createEmptyBorder(14, 16, 14, 16)
        ));
        questionArea.setPreferredSize(new Dimension(0, 100));
        card.add(questionArea, BorderLayout.CENTER);

        // Options
        JPanel optionsPanel = new JPanel(new GridLayout(3, 1, 0, 8));
        optionsPanel.setOpaque(false);
        optionGroup = new ButtonGroup();
        optionBtns  = new JRadioButton[3];
        for (int i = 0; i < 3; i++) {
            optionBtns[i] = makeOptionRadio("");
            optionGroup.add(optionBtns[i]);
            optionsPanel.add(optionBtns[i]);
        }
        card.add(optionsPanel, BorderLayout.SOUTH);

        // Nav buttons
        JPanel navRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        navRow.setOpaque(false);
        JButton nextBtn   = makeSecondaryButton("Next →");
        JButton finishBtn = makePrimaryButton("Finish Quiz");
        nextBtn.addActionListener(e   -> processAnswer(false));
        finishBtn.addActionListener(e -> processAnswer(true));
        navRow.add(nextBtn);
        navRow.add(finishBtn);

        // Wrap options + nav
        JPanel bottomSection = new JPanel(new BorderLayout(0, 12));
        bottomSection.setOpaque(false);
        bottomSection.add(optionsPanel, BorderLayout.CENTER);
        bottomSection.add(navRow,       BorderLayout.SOUTH);
        card.add(bottomSection, BorderLayout.SOUTH);

        wrapper.add(card);
        quizPanel.add(wrapper, BorderLayout.CENTER);
    }

    private JRadioButton makeOptionRadio(String text) {
        JRadioButton rb = new JRadioButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (isSelected()) {
                    g2.setColor(new Color(0xEBF5FD));
                } else if (getModel().isRollover()) {
                    g2.setColor(new Color(0xF5F7FA));
                } else {
                    g2.setColor(CARD_BG);
                }
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(isSelected() ? ACCENT_BLUE : BORDER_COLOR);
                g2.setStroke(new BasicStroke(isSelected() ? 2f : 1f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        rb.setFont(FONT_BODY);
        rb.setForeground(TEXT_DARK);
        rb.setOpaque(false);
        rb.setContentAreaFilled(false);
        rb.setBorderPainted(false);
        rb.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
        rb.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        rb.addChangeListener(e -> rb.repaint());
        return rb;
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Player Details Panel
    // ════════════════════════════════════════════════════════════════════════════
    private void buildPlayerDetailsPanel() {
        playerDetailsPanel = new JPanel(new BorderLayout());
        playerDetailsPanel.setBackground(CONTENT_BG);
        playerDetailsPanel.add(makeContentHeader("Player Details", "Look up a competitor by ID"), BorderLayout.NORTH);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(CONTENT_BG);

        JPanel card = makeCard();
        card.setLayout(new BorderLayout(0, 16));
        card.setPreferredSize(new Dimension(580, 440));
        card.setBorder(BorderFactory.createEmptyBorder(28, 32, 28, 32));

        // Search row
        JPanel searchRow = new JPanel(new BorderLayout(12, 0));
        searchRow.setOpaque(false);
        JTextField idField = makeTextField("Enter Competitor ID...");
        JButton searchBtn  = makePrimaryButton("Search");
        searchRow.add(idField,    BorderLayout.CENTER);
        searchRow.add(searchBtn,  BorderLayout.EAST);
        card.add(searchRow, BorderLayout.NORTH);

        // Result area
        JTextArea detailsArea = new JTextArea("No competitor selected yet.");
        detailsArea.setEditable(false);
        detailsArea.setFont(FONT_MONO);
        detailsArea.setForeground(TEXT_DARK);
        detailsArea.setBackground(new Color(0xF8F9FA));
        detailsArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR),
            BorderFactory.createEmptyBorder(14, 16, 14, 16)
        ));
        card.add(new JScrollPane(detailsArea), BorderLayout.CENTER);

        searchBtn.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText().trim());
                Competitor c = competitorDAO.getCompetitorWithScores(id);
                detailsArea.setText(c != null ? c.toString() : "No competitor found with ID: " + id);
            } catch (NumberFormatException ex) {
                showError("Invalid Input", "Please enter a valid numeric ID.");
            } catch (SQLException ex) {
                showError("Database Error", ex.getMessage());
            }
        });

        wrapper.add(card);
        playerDetailsPanel.add(wrapper, BorderLayout.CENTER);
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Highscores Panel
    // ════════════════════════════════════════════════════════════════════════════
    private void buildHighscoresPanel() {
        highscoresPanel = new JPanel(new BorderLayout());
        highscoresPanel.setBackground(CONTENT_BG);
        highscoresPanel.add(makeContentHeader("Highscores", "Top 5 all-time best scores"), BorderLayout.NORTH);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(CONTENT_BG);

        JPanel card = makeCard();
        card.setLayout(new BorderLayout());
        card.setPreferredSize(new Dimension(600, 380));
        card.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        // Table header
        JPanel tableHeader = new JPanel(new GridLayout(1, 5, 0, 0));
        tableHeader.setBackground(ACCENT_DARK);
        tableHeader.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        String[] cols = {"Rank", "Name", "Age", "Level", "Score"};
        for (String col : cols) {
            JLabel lbl = new JLabel(col, SwingConstants.LEFT);
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lbl.setForeground(new Color(0xBDC3CC));
            tableHeader.add(lbl);
        }
        card.add(tableHeader, BorderLayout.NORTH);

        // Table body
        JPanel tableBody = new JPanel();
        tableBody.setLayout(new BoxLayout(tableBody, BoxLayout.Y_AXIS));
        tableBody.setBackground(CARD_BG);
        tableBody.setName("tableBody");
        JScrollPane scroll = new JScrollPane(tableBody);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(CARD_BG);
        card.add(scroll, BorderLayout.CENTER);

        // Refresh button
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 12));
        footer.setBackground(new Color(0xFAFAFA));
        footer.setBorder(new MatteBorder(1, 0, 0, 0, BORDER_COLOR));
        JButton refreshBtn = makeSecondaryButton("⟳  Refresh");
        footer.add(refreshBtn);
        card.add(footer, BorderLayout.SOUTH);

        refreshBtn.addActionListener(e -> populateHighscoreTable(tableBody));

        wrapper.add(card);
        highscoresPanel.add(wrapper, BorderLayout.CENTER);
    }

    private void loadAndShowHighscores() {
        // Find tableBody panel and refresh
        for (Component c : highscoresPanel.getComponents()) {
            if (c instanceof JPanel) {
                findAndRefreshTableBody((JPanel) c);
            }
        }
        contentLayout.show(contentPanel, "highscores");
    }

    private void findAndRefreshTableBody(JPanel parent) {
        for (Component c : parent.getComponents()) {
            if (c instanceof JPanel) {
                JPanel p = (JPanel) c;
                if ("tableBody".equals(p.getName())) {
                    populateHighscoreTable(p);
                    return;
                }
                findAndRefreshTableBody(p);
            } else if (c instanceof JScrollPane) {
                Component view = ((JScrollPane) c).getViewport().getView();
                if (view instanceof JPanel && "tableBody".equals(((JPanel) view).getName())) {
                    populateHighscoreTable((JPanel) view);
                    return;
                }
            }
        }
    }

    private void populateHighscoreTable(JPanel tableBody) {
        tableBody.removeAll();
        try {
            List<Competitor> list = competitorDAO.getHighScores(5);
            if (list.isEmpty()) {
                JLabel empty = new JLabel("No scores recorded yet.", SwingConstants.CENTER);
                empty.setFont(FONT_BODY);
                empty.setForeground(TEXT_MUTED);
                empty.setBorder(BorderFactory.createEmptyBorder(40, 0, 40, 0));
                tableBody.add(empty);
            } else {
                int rank = 1;
                for (Competitor comp : list) {
                    JPanel row = new JPanel(new GridLayout(1, 5, 0, 0));
                    row.setBackground(rank % 2 == 0 ? new Color(0xF9FAFB) : CARD_BG);
                    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
                    row.setPreferredSize(new Dimension(0, 48));
                    row.setBorder(BorderFactory.createCompoundBorder(
                        new MatteBorder(0, 0, 1, 0, BORDER_COLOR),
                        BorderFactory.createEmptyBorder(0, 20, 0, 20)
                    ));
                    String[] values = {
                        "#" + rank,
                        comp.getName(),
                        String.valueOf(comp.getAge()),
                        comp.getLevel() != null ? comp.getLevel() : "N/A",
                        String.valueOf(comp.getHighScore())
                    };
                    for (int i = 0; i < values.length; i++) {
                        JLabel cell = new JLabel(values[i], SwingConstants.LEFT);
                        cell.setFont(i == 0 ? new Font("Segoe UI", Font.BOLD, 14) : FONT_BODY);
                        cell.setForeground(i == 0 ? ACCENT_BLUE : TEXT_DARK);
                        row.add(cell);
                    }
                    tableBody.add(row);
                    rank++;
                }
            }
        } catch (SQLException e) {
            showError("Database Error", e.getMessage());
        }
        tableBody.revalidate();
        tableBody.repaint();
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Admin Panel
    // ════════════════════════════════════════════════════════════════════════════
    private void buildAdminPanel() {
        adminPanel = new JPanel(new BorderLayout());
        adminPanel.setBackground(CONTENT_BG);
        adminPanel.add(makeContentHeader("Admin Panel", "Manage quiz questions"), BorderLayout.NORTH);

        adminLayout  = new CardLayout();
        adminContent = new JPanel(adminLayout);
        adminContent.setBackground(CONTENT_BG);

        adminContent.add(buildAdminMenuCard(),      "menu");
        adminContent.add(buildAddQuestionCard(),    "add");
        adminContent.add(buildUpdateQuestionCard(), "update");
        adminContent.add(buildViewQuestionsCard(),  "view");
        adminContent.add(buildDeleteQuestionCard(), "delete");

        adminLayout.show(adminContent, "menu");
        adminPanel.add(adminContent, BorderLayout.CENTER);
    }

    private JPanel buildAdminMenuCard() {
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(CONTENT_BG);

        JPanel grid = new JPanel(new GridLayout(2, 2, 16, 16));
        grid.setOpaque(false);
        grid.setPreferredSize(new Dimension(540, 260));

        String[][] items = {
            {"➕  Add Question",    "add"},
            {"✏️  Update Question", "update"},
            {"👁  View Questions",  "view"},
            {"🗑  Delete Question", "delete"}
        };
        for (String[] item : items) {
            JPanel tile = makeAdminTile(item[0], item[1]);
            grid.add(tile);
        }
        wrapper.add(grid);
        return wrapper;
    }

    private JPanel makeAdminTile(String label, String target) {
        JPanel tile = makeCard();
        tile.setLayout(new GridBagLayout());
        tile.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JLabel lbl = new JLabel(label, SwingConstants.CENTER);
        lbl.setFont(FONT_HEADING);
        lbl.setForeground(TEXT_DARK);
        tile.add(lbl);

        tile.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if ("view".equals(target)) refreshViewQuestionsArea();
                adminLayout.show(adminContent, target);
            }
            @Override public void mouseEntered(MouseEvent e) {
                tile.setBackground(new Color(0xEBF5FD));
                tile.repaint();
            }
            @Override public void mouseExited(MouseEvent e) {
                tile.setBackground(CARD_BG);
                tile.repaint();
            }
        });
        return tile;
    }

    private JPanel buildAddQuestionCard() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(CONTENT_BG);

        JPanel card = makeCard();
        card.setLayout(new BorderLayout(0, 16));
        card.setBorder(BorderFactory.createEmptyBorder(24, 32, 24, 32));

        JLabel heading = makeLabel("Add New Question", new Font("Segoe UI", Font.BOLD, 17), TEXT_DARK);
        card.add(heading, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(7, 2, 12, 10));
        form.setOpaque(false);

        JTextField questionField      = makeTextField("Question text");
        JTextField option1Field       = makeTextField("Option 1");
        JTextField option2Field       = makeTextField("Option 2");
        JTextField option3Field       = makeTextField("Option 3");
        JTextField correctAnswerField = makeTextField("1, 2 or 3");
        JComboBox<String> levelBox    = makeStyledCombo(new String[]{"beginner", "intermediate", "advanced"});

        addFormRow(form, "Question:", questionField);
        addFormRow(form, "Option 1:", option1Field);
        addFormRow(form, "Option 2:", option2Field);
        addFormRow(form, "Option 3:", option3Field);
        addFormRow(form, "Correct Answer (1-3):", correctAnswerField);
        addFormRow(form, "Level:", levelBox);
        card.add(form, BorderLayout.CENTER);

        // Buttons
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnRow.setOpaque(false);
        JButton backBtn = makeSecondaryButton("← Back");
        JButton addBtn  = makePrimaryButton("Add Question");

        backBtn.addActionListener(e -> adminLayout.show(adminContent, "menu"));
        addBtn.addActionListener(e -> {
            try {
                String[] opts = {option1Field.getText(), option2Field.getText(), option3Field.getText()};
                int correct   = Integer.parseInt(correctAnswerField.getText().trim()) - 1;
                if (correct < 0 || correct > 2) { showError("Invalid", "Correct answer must be 1, 2, or 3."); return; }
                questionDAO.addQuestion(new Question(0, questionField.getText(), opts, correct, (String) levelBox.getSelectedItem()));
                showInfo("Success", "Question added successfully!");
                clearFields(questionField, option1Field, option2Field, option3Field, correctAnswerField);
                levelBox.setSelectedIndex(0);
            } catch (NumberFormatException ex) {
                showError("Invalid", "Enter a valid number for the correct answer.");
            } catch (SQLException ex) {
                showError("Database Error", ex.getMessage());
            }
        });

        btnRow.add(backBtn);
        btnRow.add(addBtn);
        card.add(btnRow, BorderLayout.SOUTH);

        wrapper.add(card, BorderLayout.CENTER);
        wrapper.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        return wrapper;
    }

    private JPanel buildUpdateQuestionCard() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(CONTENT_BG);

        JPanel card = makeCard();
        card.setLayout(new BorderLayout(0, 16));
        card.setBorder(BorderFactory.createEmptyBorder(24, 32, 24, 32));

        card.add(makeLabel("Update Question", new Font("Segoe UI", Font.BOLD, 17), TEXT_DARK), BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(8, 2, 12, 10));
        form.setOpaque(false);

        JTextField idField            = makeTextField("Question ID");
        JTextField questionField      = makeTextField("New question text");
        JTextField option1Field       = makeTextField("Option 1");
        JTextField option2Field       = makeTextField("Option 2");
        JTextField option3Field       = makeTextField("Option 3");
        JTextField correctAnswerField = makeTextField("1, 2 or 3");
        JComboBox<String> levelBox    = makeStyledCombo(new String[]{"beginner", "intermediate", "advanced"});

        addFormRow(form, "Question ID:", idField);
        addFormRow(form, "Question:", questionField);
        addFormRow(form, "Option 1:", option1Field);
        addFormRow(form, "Option 2:", option2Field);
        addFormRow(form, "Option 3:", option3Field);
        addFormRow(form, "Correct Answer (1-3):", correctAnswerField);
        addFormRow(form, "Level:", levelBox);
        card.add(form, BorderLayout.CENTER);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnRow.setOpaque(false);
        JButton backBtn   = makeSecondaryButton("← Back");
        JButton updateBtn = makePrimaryButton("Update Question");

        backBtn.addActionListener(e -> adminLayout.show(adminContent, "menu"));
        updateBtn.addActionListener(e -> {
            try {
                int id      = Integer.parseInt(idField.getText().trim());
                String[] opts = {option1Field.getText(), option2Field.getText(), option3Field.getText()};
                int correct   = Integer.parseInt(correctAnswerField.getText().trim()) - 1;
                questionDAO.updateQuestion(new Question(id, questionField.getText(), opts, correct, (String) levelBox.getSelectedItem()));
                showInfo("Success", "Question updated successfully!");
                clearFields(idField, questionField, option1Field, option2Field, option3Field, correctAnswerField);
            } catch (NumberFormatException ex) {
                showError("Invalid", "Enter valid numbers.");
            } catch (SQLException ex) {
                showError("Database Error", ex.getMessage());
            }
        });

        btnRow.add(backBtn);
        btnRow.add(updateBtn);
        card.add(btnRow, BorderLayout.SOUTH);

        wrapper.add(card, BorderLayout.CENTER);
        wrapper.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        return wrapper;
    }

    private JPanel buildViewQuestionsCard() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(CONTENT_BG);

        JPanel card = makeCard();
        card.setLayout(new BorderLayout(0, 12));
        card.setBorder(BorderFactory.createEmptyBorder(24, 32, 24, 32));
        card.add(makeLabel("All Questions", new Font("Segoe UI", Font.BOLD, 17), TEXT_DARK), BorderLayout.NORTH);

        viewQuestionsArea = new JTextArea();
        viewQuestionsArea.setEditable(false);
        viewQuestionsArea.setFont(FONT_MONO);
        viewQuestionsArea.setForeground(TEXT_DARK);
        viewQuestionsArea.setBackground(new Color(0xF8F9FA));
        viewQuestionsArea.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        JScrollPane scroll = new JScrollPane(viewQuestionsArea);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        card.add(scroll, BorderLayout.CENTER);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        btnRow.setOpaque(false);
        JButton backBtn = makeSecondaryButton("← Back");
        backBtn.addActionListener(e -> adminLayout.show(adminContent, "menu"));
        btnRow.add(backBtn);
        card.add(btnRow, BorderLayout.SOUTH);

        wrapper.add(card, BorderLayout.CENTER);
        wrapper.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        return wrapper;
    }

    private void refreshViewQuestionsArea() {
        try {
            List<Question> all = questionDAO.getAllQuestions();
            StringBuilder sb   = new StringBuilder();
            for (Question q : all) {
                sb.append(q.toString()).append("\n").append("─".repeat(48)).append("\n");
            }
            viewQuestionsArea.setText(sb.isEmpty() ? "No questions found." : sb.toString());
            viewQuestionsArea.setCaretPosition(0);
        } catch (SQLException e) {
            showError("Database Error", e.getMessage());
        }
    }

    private JPanel buildDeleteQuestionCard() {
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(CONTENT_BG);

        JPanel card = makeCard();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(36, 48, 36, 48));
        card.setPreferredSize(new Dimension(480, 260));

        JLabel heading = makeLabel("Delete Question", new Font("Segoe UI", Font.BOLD, 17), TEXT_DARK);
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtext = makeLabel("Enter the ID of the question you want to permanently remove.", FONT_SMALL, TEXT_MUTED);
        subtext.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextField idField = makeTextField("Question ID");
        idField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        idField.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        btnRow.setOpaque(false);
        btnRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        JButton backBtn   = makeSecondaryButton("← Back");
        JButton deleteBtn = new JButton("Delete");
        deleteBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        deleteBtn.setBackground(DANGER_COLOR);
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setBorder(BorderFactory.createEmptyBorder(10, 22, 10, 22));
        deleteBtn.setFocusPainted(false);
        deleteBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        backBtn.addActionListener(e -> adminLayout.show(adminContent, "menu"));
        deleteBtn.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText().trim());
                int ok = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete question ID " + id + "?",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                if (ok == JOptionPane.YES_OPTION) {
                    questionDAO.deleteQuestion(id);
                    showInfo("Deleted", "Question deleted successfully.");
                    idField.setText("");
                }
            } catch (NumberFormatException ex) {
                showError("Invalid", "Enter a valid question ID.");
            } catch (SQLException ex) {
                showError("Database Error", ex.getMessage());
            }
        });

        btnRow.add(backBtn);
        btnRow.add(Box.createRigidArea(new Dimension(10, 0)));
        btnRow.add(deleteBtn);

        card.add(heading);
        card.add(Box.createRigidArea(new Dimension(0, 6)));
        card.add(subtext);
        card.add(Box.createRigidArea(new Dimension(0, 20)));
        card.add(idField);
        card.add(Box.createRigidArea(new Dimension(0, 20)));
        card.add(btnRow);

        wrapper.add(card);
        return wrapper;
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Quiz Logic
    // ════════════════════════════════════════════════════════════════════════════
    private void showPlayerInfoDialog() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JTextField nameField = new JTextField();
        JTextField ageField  = new JTextField();
        panel.add(new JLabel("Name:")); panel.add(nameField);
        panel.add(new JLabel("Age:"));  panel.add(ageField);

        int res = JOptionPane.showConfirmDialog(this, panel, "Player Information", JOptionPane.OK_CANCEL_OPTION);
        if (res == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String age  = ageField.getText().trim();
            if (name.isEmpty()) { showWarning("Invalid", "Please enter your name."); return; }
            try {
                int ageVal    = Integer.parseInt(age);
                competitorId  = competitorDAO.getCompetitorId(name, ageVal);
                if (competitorId == -1) {
                    competitorId = competitorDAO.createCompetitor(name, ageVal);
                    showInfo("Welcome", "Welcome, " + name + "! Your ID is: " + competitorId);
                } else {
                    showInfo("Welcome Back", "Welcome back, " + name + "! Your ID is: " + competitorId);
                }
                competitorName = name;
                startQuiz();
            } catch (NumberFormatException ex) {
                showError("Invalid", "Please enter a valid age.");
            } catch (SQLException ex) {
                showError("Database Error", ex.getMessage());
            }
        }
    }

    private void startQuiz() {
        String[] levels = {"beginner", "intermediate", "advanced"};
        String level = (String) JOptionPane.showInputDialog(this, "Select difficulty:", "Level",
            JOptionPane.QUESTION_MESSAGE, null, levels, levels[0]);
        if (level == null) return;
        try {
            competitorDAO.updateLevel(competitorId, level);
            questions = questionDAO.getQuestions(level);
            if (questions.isEmpty()) { showInfo("No Questions", "No questions found for this level."); return; }
            score = 0; currentQuestionIndex = 0;
            updateQuizUI();
            contentLayout.show(contentPanel, "quiz");
        } catch (SQLException e) {
            showError("Database Error", e.getMessage());
        }
    }

    private void updateQuizUI() {
        if (currentQuestionIndex >= questions.size()) return;
        Question q = questions.get(currentQuestionIndex);
        questionArea.setText("Q" + (currentQuestionIndex + 1) + ".  " + q.getQuestionText());
        String[] opts = q.getOptions();
        for (int i = 0; i < optionBtns.length; i++) {
            optionBtns[i].setText("  " + (char)('A' + i) + ".  " + opts[i]);
            optionBtns[i].setSelected(false);
        }
        optionGroup.clearSelection();
        scoreLabel.setText("Score: " + score);
        progressLabel.setText("Question " + (currentQuestionIndex + 1) + " / " + questions.size());
        int pct = (int) (((double)(currentQuestionIndex) / questions.size()) * 100);
        quizProgress.setValue(pct);
    }

    private void processAnswer(boolean finish) {
        int selected = -1;
        for (int i = 0; i < optionBtns.length; i++) {
            if (optionBtns[i].isSelected()) { selected = i; break; }
        }
        if (selected == -1) { showWarning("No Selection", "Please select an answer before continuing."); return; }

        if (questions.get(currentQuestionIndex).isCorrect(selected)) score++;
        currentQuestionIndex++;

        if (finish || currentQuestionIndex >= questions.size()) {
            try {
                competitorDAO.updateHighScore(competitorId, score);
                showInfo("Quiz Complete",
                    "Well done, " + competitorName + "!\n" +
                    "Final Score: " + score + " / " + questions.size());
                contentLayout.show(contentPanel, "home");
            } catch (SQLException e) {
                showError("Database Error", e.getMessage());
            }
        } else {
            updateQuizUI();
        }
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Admin Login
    // ════════════════════════════════════════════════════════════════════════════
    private void showAdminLoginDialog(JButton navBtn) {
        JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JTextField userField = new JTextField();
        JPasswordField passField = new JPasswordField();
        panel.add(new JLabel("Username:")); panel.add(userField);
        panel.add(new JLabel("Password:")); panel.add(passField);

        int res = JOptionPane.showConfirmDialog(this, panel, "Admin Login", JOptionPane.OK_CANCEL_OPTION);
        if (res == JOptionPane.OK_OPTION) {
            if (userField.getText().equals(ADMIN_USERNAME) &&
                new String(passField.getPassword()).equals(ADMIN_PASSWORD)) {
                setActiveNavButton(navBtn);
                adminLayout.show(adminContent, "menu");
                contentLayout.show(contentPanel, "admin");
            } else {
                showError("Login Failed", "Invalid username or password.");
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Shared UI Component Factory
    // ════════════════════════════════════════════════════════════════════════════

    /** White rounded card panel */
    private JPanel makeCard() {
        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 18));
                g2.fillRoundRect(3, 3, getWidth() - 3, getHeight() - 3, 16, 16);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth() - 3, getHeight() - 3, 16, 16);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setBackground(CARD_BG);
        return card;
    }

    /** Top content area header with title + subtitle */
    private JPanel makeContentHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(CARD_BG);
        header.setBorder(new CompoundBorder(
            new MatteBorder(0, 0, 1, 0, BORDER_COLOR),
            BorderFactory.createEmptyBorder(20, 32, 18, 32)
        ));
        JLabel titleLbl    = makeLabel(title, FONT_TITLE, TEXT_DARK);
        JLabel subtitleLbl = makeLabel(subtitle, FONT_BODY, TEXT_MUTED);
        header.add(titleLbl,    BorderLayout.NORTH);
        header.add(subtitleLbl, BorderLayout.SOUTH);
        return header;
    }

    private JLabel makeLabel(String text, Font font, Color color) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(font);
        lbl.setForeground(color);
        return lbl;
    }

    /** Standard filled primary button */
    private JButton makePrimaryButton(String text) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? ACCENT_BLUE.darker() : ACCENT_BLUE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        styleButton(btn, Color.WHITE);
        return btn;
    }

    /** Secondary outlined button */
    private JButton makeSecondaryButton(String text) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? new Color(0xF0F2F5) : CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(BORDER_COLOR);
                g2.setStroke(new BasicStroke(1.4f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        styleButton(btn, TEXT_DARK);
        return btn;
    }

    private void styleButton(JButton btn, Color fg) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(fg);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 22, 10, 22));
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private JTextField makeTextField(String placeholder) {
        JTextField tf = new JTextField(placeholder) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        tf.setFont(FONT_BODY);
        tf.setForeground(TEXT_MUTED);
        tf.setBackground(new Color(0xF8F9FA));
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        tf.setPreferredSize(new Dimension(0, 42));

        // Clear placeholder on focus
        tf.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) {
                if (tf.getText().equals(placeholder)) { tf.setText(""); tf.setForeground(TEXT_DARK); }
            }
            @Override public void focusLost(FocusEvent e) {
                if (tf.getText().isEmpty()) { tf.setText(placeholder); tf.setForeground(TEXT_MUTED); }
            }
        });
        return tf;
    }

    private JComboBox<String> makeStyledCombo(String[] items) {
        JComboBox<String> cb = new JComboBox<>(items);
        cb.setFont(FONT_BODY);
        cb.setBackground(new Color(0xF8F9FA));
        cb.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        cb.setPreferredSize(new Dimension(0, 42));
        return cb;
    }

    private void addFormRow(JPanel form, String labelText, JComponent field) {
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbl.setForeground(TEXT_DARK);
        form.add(lbl);
        form.add(field);
    }

    private void clearFields(JTextField... fields) {
        for (JTextField f : fields) f.setText("");
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Dialogs
    // ════════════════════════════════════════════════════════════════════════════
    private void showError(String title, String msg)   { JOptionPane.showMessageDialog(this, msg, title, JOptionPane.ERROR_MESSAGE); }
    private void showInfo(String title, String msg)    { JOptionPane.showMessageDialog(this, msg, title, JOptionPane.INFORMATION_MESSAGE); }
    private void showWarning(String title, String msg) { JOptionPane.showMessageDialog(this, msg, title, JOptionPane.WARNING_MESSAGE); }

    // ════════════════════════════════════════════════════════════════════════════
    //  Cleanup
    // ════════════════════════════════════════════════════════════════════════════
    private void closeApp() {
        try {
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException e) { e.printStackTrace(); }
        System.exit(0);
    }

    // ════════════════════════════════════════════════════════════════════════════
    //  Entry Point
    // ════════════════════════════════════════════════════════════════════════════
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(QuizGUI::new);
    }
}