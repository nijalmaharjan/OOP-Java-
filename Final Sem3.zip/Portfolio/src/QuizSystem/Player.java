package QuizSystem;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Player class - handles player interactions with the quiz system
public class Player {
    
    // Stores high scores for current session
    private static List<Double> sessionHighScores = new ArrayList<>();

    // Runs the player menu
    public static void runPlayerPanel(Scanner scanner, Connection connection) throws SQLException {
        
        boolean running = true;
        
        while (running) {
            System.out.println("\nPlayer Menu:");
            System.out.println("1. Take a Quiz");
            System.out.println("2. View Session Scores");
            System.out.println("3. Back to Main Menu");
            System.out.print("Enter your choice: ");
            
            // Validate input
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
                System.out.print("Enter your choice: ");
            }
            
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    startQuizFlow(scanner, connection);
                    break;
                case 2:
                    viewSessionScores();
                    break;
                case 3:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Handles the complete quiz flow
    private static void startQuizFlow(Scanner scanner, Connection connection) throws SQLException {
        
        // Get player info and create/find in database
        int competitorId = getOrCreatePlayer(scanner, connection);
        
        if (competitorId == -1) {
            System.out.println("Failed to register player.");
            return;
        }
        
        // Choose difficulty and take quiz
        String difficulty = chooseDifficulty(scanner);
        
        // Update player's level in database
        CompetitorDAO competitorDAO = new CompetitorDAO(connection);
        competitorDAO.updateLevel(competitorId, difficulty);
        
        // Take the quiz
        double score = takeQuiz(scanner, difficulty, connection);
        
        // Update high score in database
        competitorDAO.updateHighScore(competitorId, (int) score);
    }

    // Gets player info and creates or finds them in database
    private static int getOrCreatePlayer(Scanner scanner, Connection connection) throws SQLException {
        
        CompetitorDAO competitorDAO = new CompetitorDAO(connection);
        
        // Get player name
        System.out.print("Enter your name: ");
        String name = scanner.nextLine().trim();
        
        if (name.isEmpty()) {
            System.out.println("Name cannot be empty.");
            return -1;
        }

        // Get player age
        System.out.print("Enter your age: ");
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next();
            System.out.print("Enter your age: ");
        }
        int age = scanner.nextInt();
        scanner.nextLine();
        
        // Validate age
        if (age < 1 || age > 120) {
            System.out.println("Invalid age.");
            return -1;
        }

        // Check if player already exists
        int competitorId = competitorDAO.getCompetitorId(name, age);
        
        if (competitorId == -1) {
            // Create new player
            competitorId = competitorDAO.createCompetitor(name, age);
            System.out.println("Welcome, " + name + "! Your ID is: " + competitorId);
        } else {
            // Existing player
            System.out.println("Welcome back, " + name + "!");
        }
        
        return competitorId;
    }

    // Lets player choose difficulty level
    private static String chooseDifficulty(Scanner scanner) {
        
        System.out.println("\nSelect Difficulty:");
        System.out.println("1. Beginner");
        System.out.println("2. Intermediate");
        System.out.println("3. Advanced");
        System.out.print("Enter your choice: ");
        
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next();
            System.out.print("Enter your choice: ");
        }
        
        int choice = scanner.nextInt();
        scanner.nextLine();

        // Return difficulty based on choice
        switch (choice) {
            case 1:
                return "beginner";
            case 2:
                return "intermediate";
            case 3:
                return "advanced";
            default:
                System.out.println("Invalid choice. Defaulting to Beginner.");
                return "beginner";
        }
    }

    // Runs the quiz and returns the score
    private static double takeQuiz(Scanner scanner, String difficulty, Connection connection) throws SQLException {
        
        QuestionDAO questionDAO = new QuestionDAO(connection);
        List<Question> questions = questionDAO.getQuestions(difficulty);
        
        // Check if questions exist
        if (questions.isEmpty()) {
            System.out.println("No questions found for this level. Please choose another level.");
            return 0;
        }

        // Score multiplier based on difficulty
        double scoreMultiplier = getScoreMultiplier(difficulty);
        
        int correctAnswers = 0;
        int questionNumber = 0;

        System.out.println("\nStarting Quiz - " + difficulty.toUpperCase() + " Level");
        System.out.println("Total Questions: " + questions.size());
        System.out.println("Score Multiplier: " + scoreMultiplier + "x\n");

        // Loop through each question
        for (Question question : questions) {
            questionNumber++;
            
            // Display question
            System.out.println("Q" + questionNumber + ": " + question.getQuestionText());
            
            // Display options
            String[] options = question.getOptions();
            for (int i = 0; i < options.length; i++) {
                System.out.println("   " + (i + 1) + ". " + options[i]);
            }

            // Get answer from user
            int userAnswer = getUserAnswer(scanner, options.length);

            // Check if correct
            if (question.isCorrect(userAnswer)) {
                System.out.println("Correct!\n");
                correctAnswers++;
            } else {
                int correctIndex = question.getCorrectAnswerIndex();
                System.out.println("Incorrect! The correct answer was: " + 
                    (correctIndex + 1) + ". " + options[correctIndex] + "\n");
            }
        }

        // Calculate final score
        double finalScore = correctAnswers * scoreMultiplier;
        
        // Store score in session list
        sessionHighScores.add(finalScore);

        // Display results
        System.out.println("Quiz Complete!");
        System.out.println("Correct Answers: " + correctAnswers + "/" + questions.size());
        System.out.println("Final Score: " + finalScore);

        return finalScore;
    }

    // Gets the score multiplier based on difficulty
    private static double getScoreMultiplier(String difficulty) {
        switch (difficulty.toLowerCase()) {
            case "beginner":
                return 1.0;
            case "intermediate":
                return 1.5;
            case "advanced":
                return 2.0;
            default:
                return 1.0;
        }
    }

    // Gets a valid answer from the user
    private static int getUserAnswer(Scanner scanner, int numberOfOptions) {
        
        int answer = -1;
        
        while (answer < 0 || answer >= numberOfOptions) {
            System.out.print("Your answer (1-" + numberOfOptions + "): ");
            
            if (scanner.hasNextInt()) {
                answer = scanner.nextInt() - 1; // Convert to 0-based index
                scanner.nextLine();
                
                if (answer < 0 || answer >= numberOfOptions) {
                    System.out.println("Please enter a number between 1 and " + numberOfOptions);
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
            }
        }
        
        return answer;
    }

    // Shows scores from current session
    private static void viewSessionScores() {
        
        System.out.println("\nSession Scores:");
        
        if (sessionHighScores.isEmpty()) {
            System.out.println("No scores recorded yet in this session.");
        } else {
            double totalScore = 0;
            double highestScore = 0;
            
            for (int i = 0; i < sessionHighScores.size(); i++) {
                double score = sessionHighScores.get(i);
                System.out.println("Game " + (i + 1) + ": " + score);
                
                totalScore += score;
                if (score > highestScore) {
                    highestScore = score;
                }
            }
            
            // Show summary
            System.out.println("\nTotal Games: " + sessionHighScores.size());
            System.out.println("Highest Score: " + highestScore);
            System.out.println("Average Score: " + (totalScore / sessionHighScores.size()));
        }
    }

    // Clears session scores (can be called when player logs out)
    public static void clearSessionScores() {
        sessionHighScores.clear();
    }
}