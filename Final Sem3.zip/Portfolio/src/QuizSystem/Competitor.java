package QuizSystem;

// Competitor class - stores information about a quiz participant
public class Competitor {
    
    // Private variables to store competitor data
    private int competitorId;
    private Name name;  // Changed from String to Name
    private int age;
    private String level;
    private int highScore;

    // Constructor - creates a new competitor with given details
    public Competitor(int competitorId, String fullName, int age, String level, int highScore) {
        this.competitorId = competitorId;
        this.name = new Name(fullName);  // Create Name object from string
        this.age = age;
        this.level = level;
        this.highScore = highScore;
    }
    
    // Alternative constructor using Name object directly
    public Competitor(int competitorId, Name name, int age, String level, int highScore) {
        this.competitorId = competitorId;
        this.name = name;
        this.age = age;
        this.level = level;
        this.highScore = highScore;
    }

    // Returns the competitor ID
    public int getCompetitorId() {
        return competitorId;
    }

    // Returns the competitor name as string
    public String getName() {
        return name.getFullName();
    }
    
    // Returns the Name object
    public Name getNameObject() {
        return name;
    }

    // Returns the competitor age
    public int getAge() {
        return age;
    }

    // Returns the competitor level (beginner, intermediate, advanced)
    public String getLevel() {
        return level;
    }

    // Returns the competitor high score
    public int getHighScore() {
        return highScore;
    }

    // Sets the competitor name from string
    public void setName(String fullName) {
        this.name = new Name(fullName);
    }
    
    // Sets the competitor name from Name object
    public void setName(Name name) {
        this.name = name;
    }

    // Sets the competitor age
    public void setAge(int age) {
        this.age = age;
    }

    // Sets the competitor level
    public void setLevel(String level) {
        this.level = level;
    }

    // Sets the competitor high score
    public void setHighScore(int highScore) {
        this.highScore = highScore;
    }
    
    // Returns overall score (same as high score for now)
    public double getOverallScore() {
        return highScore;
    }
    
    // Returns full details of the competitor
    public String getFullDetails() {
        return "Competitor number " + competitorId + 
               ", name " + name.getFullName() + 
               ", age " + age + ".\n" +
               name.getFirstName() + " is a " + 
               (level != null ? level : "unranked") + 
               " aged " + age + 
               " and has an overall score of " + highScore + ".";
    }
    
    // Returns short details in format: CN 100 (JD) has overall score 5.
    public String getShortDetails() {
        return "CN " + competitorId + 
               " (" + name.getInitials() + ") " +
               "has overall score " + highScore + ".";
    }

    // Returns competitor info as a readable string
    @Override
    public String toString() {
        return "Competitor ID: " + competitorId + 
               ", Name: " + name.getFullName() + 
               ", Age: " + age + 
               ", Level: " + level + 
               ", High Score: " + highScore;
    }
}